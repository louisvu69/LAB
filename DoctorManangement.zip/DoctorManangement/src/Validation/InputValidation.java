/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package validation;

import java.util.Scanner;

/**
 *
 * @author My PC
 */
public class InputValidation {
    private static final Scanner sc = new Scanner(System.in);
    
    public static int inputInt()
    {
        try {
            return Integer.parseInt(sc.nextLine());
        } catch (NumberFormatException e) {
            System.out.println("Invalid input!");
            return inputInt();
            
        }
    }
    public static String inputString()
    {   
        String x;
        try {
            return sc.nextLine();
            
        } catch (Exception e ) {
            System.out.println("Invalid input!");
            return inputString();
        }
    }
    
}
