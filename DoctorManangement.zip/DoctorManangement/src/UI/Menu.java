/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package UI;

import validation.InputValidation;
import Function.menuFunction;

/**
 *
 * @author My PC
 */

public class Menu {

    public static Boolean isExit = false;

    public static void displayMenu() {
        System.out.println("======== Doctor Management ========");
        System.out.println("   1. Add Doctor");
        System.out.println("   2. Update Doctor");
        System.out.println("   3. Delete Doctor");
        System.out.println("   4. Search Doctor");
        System.out.println("   5. Exit");
    }

    public static int getChoice() {
        return InputValidation.inputInt();
    }

    public static void run(int choice) {
        switch (choice) {
            case 1:
                menuFunction.addDoctor();
                break;
            case 2:
                menuFunction.Update();
                break;
            case 3:
                menuFunction.delete();
                break;
            case 4:
                menuFunction.search();
                break;
            case 5:
                isExit = true;
                break;
        }
    }
}
