/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Function;

import Information.Doctor;
import java.util.ArrayList;
import validation.InputValidation;

/**
 *
 * @author My PC
 */
public class menuFunction {

    private static ArrayList<Doctor> doctors = new ArrayList<Doctor>();

    public static void addDoctor() {
        System.out.println("--------- Add Doctor ---------");
        Doctor doctorList = new Doctor();
        boolean check = true;
        String checkCodeInput;

        do {
            System.out.println("Enter Code: ");
            checkCodeInput = InputValidation.inputString();
            doctorList.setCode(checkCodeInput);
            if (checkCodeInput.isEmpty()) {
                String checkCode;
                boolean checkCondition = true;
                do {
                    System.out.println("Please do not let the Code empty!");
                    System.out.println("Enter Code: ");
                    checkCode = InputValidation.inputString();
                    doctorList.setCode(checkCode);
                    checkCondition = checkCode.isEmpty();
                } while (checkCondition);
            }

            System.out.println("Enter Name: ");
            doctorList.setName(InputValidation.inputString());
            System.out.println("Enter Specialization:");
            doctorList.setSpecializtion(InputValidation.inputString());
            System.out.println("Enter Availability");
            doctorList.setAvailability(InputValidation.inputInt());
            doctors.add(doctorList);
            check = false;
        } while (check);
    }

    private static Doctor getDoctorByCode(String code) {

        for (Doctor doctorCode : doctors) {
            if (doctorCode.getCode().equals(code)) {
                return doctorCode;
            }
        }
        return null;
    }

    private static Doctor getDoctorByName(String name) {

        for (Doctor doctorName : doctors) {
            if (doctorName.getName().equals(name)) {
                return doctorName;
            }
        }
        return null;
    }

    private static Doctor getDoctorBySpecializattion(String specializattion) {

        for (Doctor doctorspecializattion : doctors) {
            if (doctorspecializattion.getSpecializtion().equals(specializattion)) {
                return doctorspecializattion;
            }
        }
        return null;
    }

    private static Doctor getDoctorByAvailability(int availability) {

        for (Doctor doctorAvailability : doctors) {
            if (doctorAvailability.getAvailability() == availability) {
                return doctorAvailability;
            }
        }
        return null;
    }

    public static void Update() {
        System.out.println("--------- Update Doctor ---------");
        System.out.println("Enter code of doctor you want to update: ");
        String code = InputValidation.inputString();
        Doctor dL = new Doctor();
        Doctor dLCode = getDoctorByCode(code);
        if (dLCode != null) {
            System.out.println("Enter Code");
            dL.setCode(InputValidation.inputString());
            System.out.println("Enter Name: ");
            dL.setName(InputValidation.inputString());
            System.out.println("Enter Specialization: ");
            dL.setSpecializtion(InputValidation.inputString());
            System.out.println("Enter Availability: ");
            dL.setAvailability(InputValidation.inputInt());
        } else {
            System.out.println("Code not found!");
        }
    }

    public static void display() {
        doctors.forEach((doctor) -> {
            System.out.println(doctor.toString());
        });
    }

    public static void delete() {
        System.out.println("--------- Delete Doctor ---------");
        System.out.println("Enter Code : ");
        String code = InputValidation.inputString();
        Doctor dLCode = getDoctorByCode(code);
        if (dLCode != null) {
            doctors.remove(dLCode);
        } else {
            System.out.println("Code not found!");
        }
    }

    public static void search() {
        System.out.println("--------- Search Doctor ---------");
        System.out.println("Enter text : ");
        String text = InputValidation.inputString();
        Doctor dLCode = getDoctorByCode(text);
        Doctor dLSpecialization = getDoctorBySpecializattion(text);
        Doctor dLName = getDoctorByName(text);
        Doctor dLAvailability = getDoctorByAvailability(Integer.parseInt(text));

        if (dLCode != null) {
            System.out.println("----------- Result ----------");
            System.out.println(dLCode.toString());
        } else if (dLAvailability != null) {
            System.out.println("----------- Result ----------");
            System.out.println(dLAvailability.toString());
        } else if (dLName != null) {
            System.out.println("----------- Result ----------");
            System.out.println(dLName.toString());
        } else if (dLSpecialization != null) {
            System.out.println("----------- Result ----------");
            System.out.println(dLSpecialization.toString());
        } else if (text.isEmpty()) {
            System.out.println("----------- Result ----------");
            doctors.forEach((doctor) -> {
                doctor.toString();
            });
        } else {
            System.out.println("Not found!");
        }

    }
}
